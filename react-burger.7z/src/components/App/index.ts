export { App } from './App';
