import React from 'react';
import { CurrencyIcon } from '@ya.praktikum/react-developer-burger-ui-components';
import { v4 } from 'uuid';
import { useParams } from 'react-router-dom';
import { useSelector } from '../../services/hooks';
import styles from './OrderInfo.module.css';

export const OrderInfo = () => {
  const { currentFeed } = useSelector(store => store.feedModal);
  const { ingredientItems } = useSelector(store => store.ingredients);
  const { ingredients, name, status, createdAt } = currentFeed;

  const data = ingredientItems.filter(item => ingredients.includes(item._id));
  const total = data.reduce((acc, cur) => acc + cur.price, 0);
  const date = new Date(createdAt).toLocaleDateString('ru-RU', {
    minute: '2-digit',
    hour: '2-digit',
    day: 'numeric',
    weekday: 'long',
    month: 'long',
  });

  return (
    <>
      <h2 className="text text_type_main-medium mb-3">{name}</h2>
      <span className={`text text_type_main-default ${status === 'done' ? styles.done : ''}`}>
        {status === 'done' ? 'Выполнен' : 'Готовится'}
      </span>
      <p className="text text_type_main-medium mt-15">Состав:</p>
      <section className={`${styles.ingredients} mt-6 custom-scroll pr-6`}>
        {data &&
          ingredients &&
          data?.map(item => (
            <div key={item._id} className={`${styles.ingredientItem} mt-4`}>
              <div className={styles.ingredientItem}>
                <span className={`${styles.orderItem} `}>
                  <img src={item.image_mobile} alt="" />
                </span>
                <span className="text text_type_main-default ml-4">{item.name}</span>
              </div>
              <div className={`${styles.count}`}>
                <span className="mr-2 text text_type_digits-default mr-2">
                  {item.type === 'bun' ? `2 x ${item.price}` : item.price}
                </span>
                <CurrencyIcon type="primary" />
              </div>
            </div>
          ))}
      </section>
      <div className={`${styles.bottom} mt-10`}>
        <span className="text text_type_main-default text_color_inactive">{date}</span>
        <div className={styles.bottom}>
          <span className="text text_type_digits-default mr-2">{total}</span>
          <CurrencyIcon type="primary" />
        </div>
      </div>
    </>
  );
};
