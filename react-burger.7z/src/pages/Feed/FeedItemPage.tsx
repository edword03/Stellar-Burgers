import React from 'react'

export const FeedItem = () => {
  return (
    <div>
      
    </div>
  )
}
