import React from 'react';
import { OrderInfo } from '../../components/OrderInfo';
import { useSelector } from '../../services/hooks';
import styles from './FeedItem.module.css';

export const FeedItemPage = () => {
  const { ingredientItems } = useSelector(store => store.ingredients);
  const { orders } = useSelector(store => store.feed);
  console.log('orders: ', orders);

  return (
    <div className={styles.container}>
      <OrderInfo />
    </div>
  );
};
